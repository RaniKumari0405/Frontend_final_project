const form = document.getElementById('myForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const phoneInput = document.getElementById('phone');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const successMessage = document.getElementById('successMessage');

nameInput.addEventListener('blur', () => {
    if (nameInput.value.trim() === '') {
        document.getElementById('nameError').textContent = 'Name is required';
    } else {
        document.getElementById('nameError').textContent = '';
    }
});

emailInput.addEventListener('blur', () => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(emailInput.value.trim())) {
        document.getElementById('emailError').textContent = 'Invalid email format';
    } else {
        document.getElementById('emailError').textContent = '';
    }
});

phoneInput.addEventListener('blur', () => {
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phoneInput.value.trim())) {
        document.getElementById('phoneError').textContent = 'Invalid phone number';
    } else {
        document.getElementById('phoneError').textContent = '';
    }
});

passwordInput.addEventListener('blur', () => {
    if (passwordInput.value.trim().length < 8) {
        document.getElementById('passwordError').textContent = 'Password must be at least 8 characters long';
    } else {
        document.getElementById('passwordError').textContent = '';
    }
});
