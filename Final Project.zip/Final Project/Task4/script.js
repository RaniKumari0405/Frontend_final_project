const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const loadingElement = document.getElementById('loading');
const errorElement = document.getElementById('error');
const repositoriesElement = document.getElementById('repositories');

let debounceTimeout;

searchButton.addEventListener('click', () => {
    const username = searchInput.value.trim();
    if (username) {
        fetchRepositories(username);
    }
});

searchInput.addEventListener('input', () => {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
        const username = searchInput.value.trim();
        if (username) {
            fetchRepositories(username);
        }
    }, 500);
});

async function fetchRepositories(username) {
    try {
        loadingElement.style.display = 'block';
        errorElement.style.display = 'none';
        repositoriesElement.innerHTML = '';

        const response = await axios.get(`https://api.github.com/users/${username}/repos`);
        const repositories = response.data;

        repositories.forEach(repository => {
            const repositoryElement = document.createElement('div');
            repositoryElement.classList.add('repository');
            repositoryElement.innerHTML = `
                <h2>${repository.name}</h2>
                <p>${repository.description || 'No description'}</p>
                <a href="${repository.html_url}" target="_blank">View on GitHub</a>
            `;
            repositoriesElement.appendChild(repositoryElement);
        });
    } catch (error) {
        errorElement.style.display = 'block';
        errorElement.textContent = 'Error fetching repositories';
    } finally {
        loadingElement.style.display = 'none';
    }
}
